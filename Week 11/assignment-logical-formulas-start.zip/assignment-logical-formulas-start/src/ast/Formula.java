package ast;

public interface Formula {
}
