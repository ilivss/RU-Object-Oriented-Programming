package polynomials;

import org.junit.Test;

import static org.junit.Assert.*;

public class PolynomialTest {

    @Test
    public void plus() {
        /* Test empty addition */
        Polynomial p1 = new Polynomial("-2 5 2 3");
        Polynomial p2 = new Polynomial("2 5 8 3");
        p1.plus(p2);
        assertEquals("10,00x^3", p1.toString());
    }

    @Test
    public void plusEmpty(){
        Polynomial p2 = new Polynomial("");
        Polynomial p1 = new Polynomial("2 5 8 5");
        p1.plus(p2);
        assertEquals("2,00x^5+8,00x^5", p1.toString());
    }

    @Test
    public void plusLarge(){
        Polynomial p1 = new Polynomial("1 1 2 2 3 3 4 4 5 5");
        Polynomial p2 = new Polynomial("6 6 7 7 8 8 9 9 10 10");
        p1.plus(p2);
        assertEquals("1,00x+2,00x^2+3,00x^3+4,00x^4+5,00x^5+6,00x^6+7,00x^7+8,00x^8+9,00x^9+10,00x^10", p1.toString());
    }

    @Test
    public void plusCommutativity(){
        Polynomial p1 = new Polynomial("5 1 3 2 2 3");
        Polynomial p2 = new Polynomial("8 1 7 2 3 3");
        p1.plus(p2);
        Polynomial p3 = new Polynomial("8 1 7 2 3 3");
        Polynomial p4 = new Polynomial("5 1 3 2 2 3");
        p3.plus(p4);
        assertEquals(p1, p3);
    }

    @Test
    public void plusAssociativity(){
        Polynomial p1 = new Polynomial("1 1");
        Polynomial p2 = new Polynomial("2 2");
        Polynomial p3 = new Polynomial("3 3");
        p1.plus(p2);
        p1.plus(p3);
        Polynomial p4 = new Polynomial("1 1");
        Polynomial p5 = new Polynomial("2 2");
        Polynomial p6 = new Polynomial("3 3");
        p5.plus(p6);
        p4.plus(p5);
        assertEquals(p1, p4);
    }

    @Test
    public void minus() {
        Polynomial p1 = new Polynomial("3 2 8 3");
        Polynomial p2 = new Polynomial("5 2 4 3");
        p1.minus(p2);
        assertEquals("-2,00x^2+4,00x^3", p1.toString());
    }

    @Test
    public void minusEqualsNegatedAddition(){
        Polynomial p1 = new Polynomial("2 2");
        Polynomial p2 = new Polynomial("3 3");
        p1.minus(p2);
        Polynomial p3 = new Polynomial("2 2");
        Polynomial p4 = new Polynomial("3 3");
        Polynomial p5 = new Polynomial("-1 0");
        p5.times(p4);
        p3.plus(p5);
        assertEquals(p1,p3);
    }

    @Test
    public void minusEmpty(){
        Polynomial p1 = new Polynomial("");
        Polynomial p2 = new Polynomial("5 2 4 3");
        p1.minus(p2);
        assertEquals("-5,00x^2-4,00x^3", p1.toString());
    }

    @Test
    public void minusSamePolynomial(){
        Polynomial p1 = new Polynomial("8 2 6 3 10 2");
        Polynomial p2 = new Polynomial("8 2 6 3 10 2");
        p1.minus(p2);
        assertEquals("0.0", p1.toString());
    }
    @Test
    public void times() {
        Polynomial p1 = new Polynomial("2 2 3 3");
        Polynomial p2 = new Polynomial("3 0 3 1");
        p1.times(p2);
        assertEquals("6,00x^2+15,00x^3+9,00x^4", p1.toString());
    }

    @Test
    public void timesItself(){
        Polynomial p1 = new Polynomial("2 2 3 3");
        p1.times(p1);
        assertEquals("4,00x^4+12,00x^5+9,00x^6", p1.toString());
    }

    @Test
    public void timesEmpty(){
        Polynomial p1 = new Polynomial("");
        Polynomial p2 = new Polynomial("88 2 102 5");
        p1.times(p2);
        assertEquals("0.0", p1.toString());
    }

    @Test
    public void timesNegative(){
        Polynomial p1 = new Polynomial("2 2 8 4");
        Polynomial p2 = new Polynomial("-3 0 -3 1");
        p1.times(p2);
        assertEquals("-6,00x^2-24,00x^4-6,00x^3-24,00x^5", p1.toString());
    }
    @Test
    public void timesCommutativity(){
        Polynomial p1 = new Polynomial("1 1 2 2 3 3");
        Polynomial p2 = new Polynomial("4 1 5 2 6 3");
        p1.times(p2);
        Polynomial p3 = new Polynomial("4 1 5 2 6 3");
        Polynomial p4 = new Polynomial("1 1 2 2 3 3");
        p3.times(p4);
        assertEquals(p1, p3);
    }

    @Test
    public void timesAssociativity(){
        Polynomial p1 = new Polynomial("1 1");
        Polynomial p2 = new Polynomial("2 2");
        Polynomial p3 = new Polynomial("3 3");
        p1.times(p2);
        p1.times(p3);
        Polynomial p4 = new Polynomial("1 1");
        Polynomial p5 = new Polynomial("2 2");
        Polynomial p6 = new Polynomial("3 3");
        p5.times(p6);
        p4.times(p5);
        assertEquals(p1, p4);
    }

    @Test
    public void distributivity(){
        Polynomial p1 = new Polynomial("1 1");
        Polynomial p2 = new Polynomial("2 2");
        Polynomial p3 = new Polynomial("3 3");
        p2.plus(p3);
        p1.times(p2);
        Polynomial p4 = new Polynomial("1 1");
        Polynomial p5 = new Polynomial("1 1");
        Polynomial p6 = new Polynomial("2 2");
        Polynomial p7 = new Polynomial("3 3");
        p4.times(p6);
        p5.times(p7);
        p4.plus(p5);
        assertEquals(p1, p4);
    }
}