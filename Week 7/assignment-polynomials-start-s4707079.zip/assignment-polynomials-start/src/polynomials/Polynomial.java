package polynomials;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import static java.lang.StrictMath.pow;

/**
 * A skeleton class for representing Polynomials
 */
public class Polynomial {

	/**
	 * A polynomial is a sequence of terms here kept in an List
	 */
	private List<Term> terms;

	/**
	 * A constructor for creating the zero Polynomial zero is presented as an empty
	 * list of terms and not as a single term with 0 as a coefficient
	 */
	public Polynomial() {
		terms = new LinkedList<>();
	}

	/**
	 * A Constructor creating a polynomial from the argument string.
	 *
	 * @param s a String representing a list of terms which is converted to a
	 *          scanner and passed to scanTerm for reading each individual term
	 */
	public Polynomial(String s) {
		terms = new LinkedList<>();
		Scanner scan = new Scanner(s);

		for (Term t = Term.scanTerm(scan); t != null; t = Term.scanTerm(scan)) {
			terms.add(t);
		}
	}

	/**
	 * The copy constructor for making a deep copy
	 *
	 * @param p the copied polynomial
	 *
	 */
	public Polynomial(Polynomial p) {
		terms = new LinkedList<>();
		for (Term t : p.terms) {
			terms.add(new Term(t));
		}
	}

	/**
	 * A straightforward conversion of a Polynomial into a string based on the
	 * toString for terms
	 *
	 * @return a readable string representation of this
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		if (terms.size() != 0){
			sb.append(terms.get(0).toString());
			for (int term = 1; term < terms.size(); term++){
				if (terms.get(term).getCoef() < 0){
					sb.append(terms.get(term).toString());
				} else {
					if (terms.get(term).getExp() == 0) {
						sb.append(String.format("+%.2f", terms.get(term).getCoef()));
					} else if (terms.get(term).getExp() == 1) {
						sb.append(String.format("+%.2fx", terms.get(term).getCoef()));
					} else {
						sb.append(String.format("+%.2fx^%d", terms.get(term).getCoef(), terms.get(term).getExp()));
					}
				}
			}
		} else sb.append("0.0");

		return sb.toString();
	}

	public void plus(Polynomial b) {
		ListIterator<Term> lita = terms.listIterator(),
				litb = b.terms.listIterator();
		while ( lita.hasNext() && litb.hasNext()){
			Term ta = lita.next(), tb = litb.next();
			if ( ta.getExp() == tb.getExp()){
				ta.plus(tb);
				if (ta.getCoef() == 0){
					lita.remove();
				}
			} else if ( ta.getExp() > tb.getExp()){
				lita.add(tb);
			} else
				tb = litb.previous();
		}

		while (litb.hasNext()){
			lita.add(litb.next());
		}
	}

	public void minus(Polynomial b) {

		ListIterator<Term> lita = terms.listIterator(),
				litb = b.terms.listIterator();
		while ( lita.hasNext() && litb.hasNext()){
			Term ta = lita.next(), tb = litb.next();
			if ( ta.getExp() == tb.getExp()){
				ta.minus(tb);
				if (ta.getCoef() == 0){
					lita.remove();
				}
			} else if ( ta.getExp() > tb.getExp()){
				Term temp = new Term(0, tb.getExp());
				temp.minus(tb);
				lita.add(temp);
			} else
				tb = litb.previous();
		}

		while (litb.hasNext()){
			Term tb = litb.next();
			Term temp = new Term(0, tb.getExp());
			temp.minus(tb);
			lita.add(temp);
		}
	}

	public void times(Polynomial b) {
		ListIterator<Term> lita = terms.listIterator();
		ListIterator<Term> litb = b.terms.listIterator();
		Polynomial p1 = new Polynomial();
		while(litb.hasNext()){
			Term tb = litb.next();
			p1.plus(polyTimesTerm(this, tb));
		}
		terms = p1.terms;
	}

	public double evualate(int x) {
		double d = 0;
		for (Term t : terms){
			d += t.getCoef() * pow((x), t.getExp());
		}
		return d;
	}

	@Override
	public boolean equals(Object other_poly) {
		if (other_poly == null || getClass() != other_poly.getClass()) {
			return false;
		}
		else {
			Polynomial p1 = (Polynomial) other_poly;
			return terms.equals(p1.terms);
		}
	}

	private Polynomial timesTerm ( Term t ){
		for(Term rt : terms){
			rt.times(t);
		}
		return this;
	}

	private static Polynomial polyTimesTerm( Polynomial p, Term t ){
		return  ( new Polynomial( p ) ).timesTerm(t);
	}
}
