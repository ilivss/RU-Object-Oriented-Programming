package hangman;

public class Main {
	public static void main(String[] args) {
		GallowsUI galgje = new GallowsUI();

		galgje.nanach();
	}
}
