package hangman;

public class HangmanTester {

	public void newGallows(String word) {
	}

	public String getWordSoFar() {
		return "";
	}

	public void guessLetter(char c) {
	}

	public String getGuessedLetters() {
		return "";
	}
	
	public boolean isWordGuessed() {
		return false;
	}
}
