package Order;

/**
 *
 * @author Sjaak
 */
public class CreditCard implements Payment {
    private final String name, date;
    private final int number, cvv;

    public CreditCard(String name, String date, int number, int cvv) {
        this.name   = name;
        this.date   = date;
        this.number = number;
        this.cvv    = cvv;
    }

    @Override
    public void pay( double amount ) {
        System.out.format("Paid %1.2f with card %d of %s\n", amount, number, name);
    }

}
