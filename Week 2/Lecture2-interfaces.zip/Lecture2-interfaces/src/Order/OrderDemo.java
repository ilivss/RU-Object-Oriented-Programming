package Order;

/**
 *
 * @author Sjaak Smetsers
 */
public class OrderDemo {

    public static void main( String [] args ) {
        ShoppingCart order = new ShoppingCart();
        order.add(new Item("Milk", 0.95));
        order.add(new Item("Shampoo", 0.87));
        
        System.out.println(order);

        order.pay( new PayPal( "Sjaak@ru.nl", "secret", 1234 ) );
    }
}





//         order.pay( new CreditCard( "Sjaak", "12/21", 10203040, 567 ) );
