package Order;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author pieterkoopman
 */
public class ShoppingCart {
    private Item[] items;
    private int nrOfItems;

    private static final int MAX_NR_OF_ITEMS = 10; 

    public ShoppingCart( ) {
        items = new Item [MAX_NR_OF_ITEMS];
        nrOfItems = 0;
    }
    
    public void add( Item item ) {
        items[nrOfItems++] = item;
    }
    
    public void pay( Payment pm ) {
        pm.pay(  total() );
    }
    

    private double total () {
        double total = 0;
        for ( int i = 0; i < nrOfItems; i++ ) {
            total = total + items[i].getPrice();
     
        }
        return total;
    }

    @Override
    public String toString() {
        StringBuilder out = new StringBuilder();
        for ( int i = 0; i < nrOfItems; i++ ) {
            out.append( items[i] + "\n" );
        }
        out.append( String.format( "%1.2f euro", total()) );
        return out.toString();
    }
}
