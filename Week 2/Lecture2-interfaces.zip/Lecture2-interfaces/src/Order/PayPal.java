package Order;

/**
 *
 * @author Sjaak
 */
public class PayPal implements Payment
{
    private final String email, password;
    private final int code;

    public PayPal(String email, String password, int code) {
        this.email = email;
        this.password = password;
        this.code = code;
    }

    @Override
    public void pay(double amount) {
        System.out.format("Pay %1.2f with paypal for %s\n", amount, email);
    }

    @Override
    public String toString() {
        return "PayPalPayment of " + email;
    }   
}
