/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package direnum;

/**
 *
 * @author Sjaak
 */
public class DirectionTest {

    public static void main(String[] args) {
        Direction dir = Direction.N;
        System.out.println (dir);
        dir = dir.turnLeft();
        System.out.println (dir);
    }
    
}
