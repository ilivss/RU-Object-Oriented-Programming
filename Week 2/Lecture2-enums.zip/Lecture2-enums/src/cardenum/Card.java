package cardenum;

class Card {

    public static enum Face {
        Ace, Deuce, Three, Four, Five, Six,
        Seven, Eight, Nine, Ten, Jack, Queen, King
    };

    public static enum Suit {
        Clubs, Diamonds, Hearts, Spades
    };

    private Face cardFace;
    private Suit cardSuit;

    // two-argument constructor
    public Card(Face cardFace, Suit cardSuit) {
        this.cardFace = cardFace; // initialize face of card
        this.cardSuit = cardSuit; // initialize suit of card

    } // end two-argument Card constructor

    // return face of the card
    public Face getFace() {
        return cardFace;
    } // end method getFace

    // return suit of Card
    public Suit getSuit() {
        return cardSuit;
    } // end method getSuit

    @Override
    public String toString() {
        String suits = "cdhs";
        String faces = "a23456789tjqk";
        
        return suits.charAt( cardSuit.ordinal() ) + "" + faces.charAt( cardFace.ordinal() );

    }

}

