package dayenum;

/**
 *
 * @author Sjaak Smetsers
 */
public class DayTest {

    enum Day {
        Mo, Tu, We, Th, Fr, Sa, Su
    };

    public static void main(String args[]) {
        Day d1 = Day.We;
        Day d2 = Day.Mo;

        if (d1.compareTo(d2) < 0) {
            System.out.println("d1 is smaller");
        } else {
            System.out.println("d1 is not smaller");
        }

    }

}
