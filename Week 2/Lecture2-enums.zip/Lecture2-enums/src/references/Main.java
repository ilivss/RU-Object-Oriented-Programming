package references;

/**
 *
 * @author Sjaak
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mainPrim();
        mainRef();
    }
    
    
    private static void mainPrim() {
        int i = 10;
        int j = 20;
        
        System.out.println( i );
        System.out.println( j );

        j = i;
        i = 50;

        System.out.println( i );
        System.out.println( j );
    }
    
    private static void mainRef() {
        Clock c1 = new Clock( 10, 12 );
        Clock c2 = new Clock( 45, 11 );

        System.out.println(c1);
        System.out.println(c2);

        c2 = c1;
        c1.setTime( 21, 30 );

        System.out.println(c1);
        System.out.println(c2);
    }

}
