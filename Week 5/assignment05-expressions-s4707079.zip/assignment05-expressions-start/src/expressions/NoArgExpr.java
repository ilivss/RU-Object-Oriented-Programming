package expressions;

public abstract class NoArgExpr implements Expression {


}
