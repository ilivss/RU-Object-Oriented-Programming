package expressions;

public class ExpressionFactory {

	public static Expression var(String x) {
		return null;
	}

	public static Expression con(Double x) {
		return null;
	}

	public static Expression add(Expression x, Expression y) {
		return null;
	}

	public static Expression mul(Expression x, Expression y) {
		return null;
	}

	public static Expression neg(Expression x) {
		return null;
	}
}
