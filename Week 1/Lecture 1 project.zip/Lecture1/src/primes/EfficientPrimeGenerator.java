package primes;

import java.util.ArrayList;

/**
 *
 * @author Sjaak
 * week 1 --- 31-1-2017
 */
class EfficientPrimeGenerator
{
    private int generatedPrimes [];
    private int nrOfGenPrimes;

    public EfficientPrimeGenerator (int n) {
        generatedPrimes = new int [n];
        nrOfGenPrimes = 0;
    }

    public int next () {
      findNextPrime ();
      return generatedPrimes[nrOfGenPrimes-1];
    }     

    private boolean isPrime (int n) {
        for (int i = 0; generatedPrimes[i] * generatedPrimes[i] <= n; i++) {
            if (n % generatedPrimes[i] == 0) {
                return false;
            }
        }
        return true;
    } 

    private void findNextPrime () {
        if (nrOfGenPrimes == 0) {
            generatedPrimes[0] = 2;
        } else {
            int n  = generatedPrimes[nrOfGenPrimes-1] + 1;
            while (! isPrime (n)) {
                n++;
            }
            generatedPrimes[nrOfGenPrimes] = n;
        }
        nrOfGenPrimes++;
    }
  
}
