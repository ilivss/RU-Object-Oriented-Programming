package car;

/**
 *
 * @author Sjaak Smetsers
 * week1 --- 31-1-2017
 */
public class Car {
    private String brand;
    private int fuelConsumption;
    private String registrationNumber;
    private String color;
    
    public Car ( String brand, int consumption, String color ) {
        this.brand = brand;
        this.fuelConsumption = consumption;
        this.color = color;
    }
    
    public void changeColor( String new_color ) {
        this.color = new_color;
    }
    
    public void setRegistrationNumber( String registration_number ) {
        this.registrationNumber = registration_number;
    }
    
    public int getFuelConsumption(){
        return fuelConsumption;
    }

    @Override
    public String toString(){
        return "A " + color + " " + brand + " with number " + registrationNumber;
    }
}
