package car;

/**
 *
 * @author Sjaak Smetsers
 * week1 --- 31-1-2017
 */
public class Lecture1Car {

    public static void main(String[] args) {
        Car dacia = new Car( "Dacia", 14, "brown" );
        dacia.setRegistrationNumber( "55-XVJ-5" );
        Car bmw = new Car( "BMW", 18, "blue" );
        bmw.setRegistrationNumber( "99-JXR-4" );
        System.out.println( dacia );
        System.out.println( bmw );
    }
    
}
