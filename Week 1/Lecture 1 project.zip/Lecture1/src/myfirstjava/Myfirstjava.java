package myfirstjava;

/**
 *
 * @author Sjaak Smetsers
 */
public class Myfirstjava {

    public static void main(String[] args) {
       Greeter world_greeter = new Greeter ("Sjaak");       
       String greeting = world_greeter.sayHello();
       System.out.println(greeting);
    }
}
