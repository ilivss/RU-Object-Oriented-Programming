package package3;

public abstract class ImplementingRunnable1 implements Runnable {
    public void doSomething() {  
    };
}
