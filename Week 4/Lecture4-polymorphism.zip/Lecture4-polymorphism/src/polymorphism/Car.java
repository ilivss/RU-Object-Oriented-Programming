package polymorphism;

/**
 *
 * @author Sjaak Smetsers
 */
public class Car extends MotorVehicle {

    public Car(String ln) {
        super(ln);
    }
}
