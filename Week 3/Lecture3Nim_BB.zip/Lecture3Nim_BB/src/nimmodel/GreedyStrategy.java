
package nimmodel;

/**
 *
 * @author Sjaak Smetsers <s.smetsers@cs.ru.nl>
 */
public class GreedyStrategy implements PlayStrategy {

    @Override
    public int numberToTake(Pile pile, int maxOnATurn) {
        return Math.min( pile.sticks(), maxOnATurn);
    }

}
