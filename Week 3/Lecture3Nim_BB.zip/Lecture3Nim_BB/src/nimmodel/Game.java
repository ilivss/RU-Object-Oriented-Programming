package nimmodel;

import nimmodel.Player;


/**
 * A manager of a simple nim game.
 */
public class Game  {
  
  private static final int MAX_ON_A_TURN = 3;  // Max sticks that can be taken on a Player''s turn.
  private Player player1;                      // The Players.
  private Player player2;
  private Player nextPlayer;                   // The Player whose turn is next.
  private Pile pile;                           // The Pile.
  
  public Game (Player player1, Player player2, int sticks) {
    assert sticks > 0 : "precondition: initial sticks > 0";
    this.player1 = player1;
    this.player2 = player2;
    this.nextPlayer = player1;
    this.pile = new Pile(sticks);
  }
  
  public int sticksLeft () {
    return pile.sticks();
  }
  
  public Player nextPlayer () {
    return nextPlayer;
  }

  public Player previousPlayer () {
    return otherPlayer(nextPlayer);
  }

  public boolean gameOver () {
    return pile.sticks() == 0;
  }
  
  public Player winner () {
    if (gameOver())
      return nextPlayer;
    else
      return null;
  }
  
  public void play () {
    if (! gameOver() ) {
      nextPlayer.takeTurn( pile,MAX_ON_A_TURN );
      nextPlayer = otherPlayer( nextPlayer );
    }
  }
  
  public String toString () {
    return "Game with players: " + player1 + ", and " + player2;
  }
  
  private Player otherPlayer (Player player) {
    if (player == player1)
      return player2;
    else
      return player1;
  }
}
