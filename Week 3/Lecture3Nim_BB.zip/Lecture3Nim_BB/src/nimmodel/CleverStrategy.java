
package nimmodel;

import java.util.Random;

/**
 *
 * @author Sjaak Smetsers <s.smetsers@cs.ru.nl>
 */
public class CleverStrategy implements PlayStrategy {
    private Random random = new Random();

    @Override
    public int numberToTake(Pile pile, int maxOnATurn) {
        int toTake = (pile.sticks() + maxOnATurn) % (maxOnATurn + 1);
        return toTake == 0 ? random.nextInt(maxOnATurn) + 1 : toTake;
    }

}
