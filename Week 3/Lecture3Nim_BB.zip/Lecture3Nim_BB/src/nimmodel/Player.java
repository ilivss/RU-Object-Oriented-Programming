package nimmodel;

import nimmodel.PlayStrategy;

/**
 * A player in the game simple nim.
 */
public class Player {
  
  private String name;
  private int sticksTaken;
  private PlayStrategy strategy;
  
  public Player (String name, PlayStrategy strategy) {
    this.name = name;
    this.strategy = strategy;
    this.sticksTaken = 0;
  }
  
  public String name () {
    return this.name;
  }
  
  public int sticksTaken () {
    return this.sticksTaken;
  }
  
  public void setStrategy (PlayStrategy strategy) {
    this.strategy = strategy;
  }
  
  public void takeTurn (Pile pile, int maxOnATurn) {
    sticksTaken = strategy.numberToTake(pile, maxOnATurn);
    pile.remove(sticksTaken);
  }
}
