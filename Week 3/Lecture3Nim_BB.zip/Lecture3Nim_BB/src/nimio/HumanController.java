package nimio;

import nimmodel.HumanStrategy;
import java.util.*;

/**
 * * A text based controller for managing an human player in the game of nim.
 */
class HumanController implements HumanObserver {

    private Scanner in;

    /**
     * Create a new HumanController.
     * in is the stream for getting user input.
     */
    public HumanController( Scanner in ) {
        this.in = in;
    }

    /**
     * The specified HumanStrategy is making a play.
     */
    public void update( HumanStrategy player, int maxOnATurn ) {
        int numberToTake = readNumberToTake( maxOnATurn );
        player.setNumberToTake(numberToTake);
    }

    /**
     * Get from the user the number of sticks to take.
     *
     */
    private int readNumberToTake( int max ) {
        int number = 0;
        while (!(0 < number && number <= max)) {
            System.out.print("Enter number to take "
                    + "(a positive integer, at most " + max
                    + "): ");
            System.out.flush();
            if (in.hasNextInt()) {
                number = in.nextInt();
            }
            in.nextLine();
        }
        return number;
    }
}
