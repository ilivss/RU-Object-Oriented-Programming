package nimio;
import java.util.Scanner;
import nimmodel.TimidStrategy;
import nimmodel.HumanStrategy;
import nimmodel.CleverStrategy;
import nimmodel.Game;
import nimmodel.Player;

/**
 * A simple text-based user interface for the game of
 * simple nim.
 */
public class NimTUI {
  
  // Main menu options:
  private static final int NO_CHOICE = 0;
  private static final int PLAY_GAME = 1;
  private static final int EXIT = 2;
  
  private Player user;      // the Players
  private Player computer;

  private Scanner in;
  
  
  /**
   * Create a new user interface.
   */
  public NimTUI () {
    HumanStrategy humanStrategy = new HumanStrategy();
    this.user     = new Player( "user", humanStrategy );
    this.computer = new Player( "computer", new CleverStrategy() );
    this.in = new Scanner(System.in);
    humanStrategy.register( new HumanController(in) );
  }
  
  /**
   * Start the interface.
   */
  public void start () {
    int choice = NO_CHOICE;
    while (choice != EXIT) {
      displayMainMenu();
      choice = readIntWithPrompt("Enter choice: ");
      executeChoice(choice);
    }
  }
  
  /**
   * Play a game with the specified number of sticks.
   */
  private void playGame (int numberOfSticks, boolean userPlaysFirst) {
    Game game = userPlaysFirst ? new Game (user, computer, numberOfSticks) : new Game (computer, user, numberOfSticks);
    while (!game.gameOver() ) {
      game.play();
      reportPlay( game );
    }
      reportWinner(game);
  }

  private void reportPlay ( Game game ) {
    Player player = game.previousPlayer();
    System.out.format("Player %s takes %d stick(s), leaving %d.\n", player.name(), player.sticksTaken(), game.sticksLeft());
  }

  private void reportWinner ( Game game ) {
    Player winner = game.winner();
    System.out.format("\nPlayer %s wins.\n\n", winner.name() );
  }
  
  /**
   * Display the main menu.
   */
  private void displayMainMenu () {
    System.out.println();
    System.out.println("Enter the number denoting the action to perform: ");
    System.out.println("Run game..............." + PLAY_GAME);
    System.out.println("Exit..................." + EXIT);
  }
  
  /**
   * Execute choice from main menu.
   */
  private void executeChoice (int choice) {
    System.out.println();
    if (choice == PLAY_GAME) {
      int numberOfSticks = readNumberOfSticks();
      boolean userPlaysFirst = readYes("User plays first? (Key yes or no): ");
      playGame(numberOfSticks,userPlaysFirst);
    } else if (choice == EXIT)
      System.out.println("Good-bye.");
  }
  
  
  /**
   * Read and return the number of sticks to play with.
   * @ensure    this.readNumberOfSticks() > 0
   */
  private int readNumberOfSticks () {
    int number = -1;
    while (number <= 0) {
      number = readIntWithPrompt("Enter number of sticks (a positive integer): ");
    }
    return number;
  }
  
  /**
   * Read a yes or no response from the user. Return true if user keys "yes."
   */
  private boolean readYes (String prompt) {
    String input = "";
    while (!(input.equalsIgnoreCase("yes") || input.equalsIgnoreCase("no"))) {
      System.out.print(prompt); System.out.flush();
      input = in.next();
      input = input.toLowerCase();
      in.nextLine();
    }
    return input.equals("yes");
  }
  
  /**
   * Read and return an int in response to the specified
   * prompt.
   */
  private int readIntWithPrompt (String prompt) {
    System.out.print(prompt); System.out.flush();
    while (!in.hasNextInt()) {
      in.nextLine();
      System.out.print(prompt); System.out.flush();
    }
    int input = in.nextInt();
    in.nextLine();
    return input;
  }
  
}

