package nimstart;

import nimio.NimTUI;

/**
 * Simple nim game driver.
 */
public class NimGame {

    public static void main(String[] argv) {
        (new NimTUI()).start();
    }
}
